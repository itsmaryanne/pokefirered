#!/usr/bin/perl
# Aplica, em CÓPIA do arquivo (stdin -> stdout), as trocas de assembly ARM inline por chamadas C.
# Uso: perl pc/patch_src.pl <nome_sem_extensao> < src/x.c > build_pc/patched/x.c
use strict; my $n=shift; local $/; my $s=<STDIN>;
$s = "#include \"../../pc/pc_compat.h\"\n".$s;
$s =~ s/^NAKED\s*$//mg;                                   # x86 não tem funções naked em C
if($n eq 'script'){ $s =~ s/asm\("svc 2"\);/PcHalt();/g }
if($n eq 'm4a')   { $s =~ s/asm\("swi 0x2A"\);/PcMusicPlayerJumpTableCopy();/g }
if($n eq 'main')  { $s =~ s/asm\("mov\\tr1, #0xC0.*?"memory"\s*\);/PcClearIwram();/s;
                    $s =~ s/^(\s*)InitRFU\(\);/$1\/\* PC: adaptador wireless (RFU) desativado \*\//m;
                    $s =~ s/^(\s*)AGBPrintInit\(\);/$1\/\* PC: log AGB (mGBA) desativado \*\//m }
if($n eq 'librfu_intr'){
  $s =~ s/asm\("bx r2"\);/callbackM(reqCommandId, error);/;
  $s =~ s/asm\("bx r1"\);/callbackS(reqCommandId);/;
  $s =~ s/asm\("bx r0"\);/callbackId();/;
}
if($n eq 'bg')    { $s =~ s/\(void \*\)IWRAM_END/(void *)0xFFFFFFFFu/ }   # no PC o heap do jogo não está em 0x02/0x03...; a checagem "fora da WRAM" sempre falharia
if($n eq 'gpu_regs'){ $s =~ s/\(vcount >= 161 && vcount <= 225\)/(1)/ }   # grava sempre na hora (no GBA a fila evita mudar registradores no meio do quadro; o port só desenha 1x por quadro e, pior, a fila perde o DISPSTAT conforme o VCOUNT no boot)
if($n eq 'naming_screen'){ $s =~ s/FREE_AND_SET_NULL\(sNamingScreen\);/free(sNamingScreen);   \/\* PC: no GBA ler NULL+deslocamento (aqui, os sprites do cursor no mesmo quadro) cai na BIOS e e inofensivo; no PC dava SIGSEGV. Mantemos o ponteiro apontando para a memoria ja liberada (continua valida no heap do jogo). \*\//g }
if($n eq 'multiboot'){ $s =~ s/asm\("mov r2, pc"\);.*?asm\("bgt MultiBootWaitCyclesLoop"\);/(void)cycles;/s }
print $s;

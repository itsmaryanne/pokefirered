// Ponte TCP do lado do jogo: permite um visualizador em OUTRO sistema (ex.: janela nativa do Windows, rodando fora
// do WSL) ver o jogo e mandar as teclas. Ativada por PC_NET_PORT=porta (padrão do run_windows.sh: 47474).
// Escuta só em 127.0.0.1 (PC_NET_BIND=ip para mudar). Protocolo: pacotes [tipo u8][tamanho u32 LE][dados].
//   jogo -> visualizador: 1 = quadro (u32 número + 240*160*4 bytes ARGB), 2 = áudio (s16 estéreo 32768 Hz)
//   visualizador -> jogo: 3 = teclas (u32, formato do REG_KEYINPUT), 4 = encerrar
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include "shared.h"

static struct PcShared *sSh;

static int SendAll(int fd, const void *p, size_t n) {
    const char *c = p;
    while (n) { ssize_t k = send(fd, c, n, MSG_NOSIGNAL); if (k <= 0) { if (k < 0 && errno == EINTR) continue; return 0; } c += k; n -= (size_t)k; }
    return 1;
}

static void *Bridge(void *arg) {
    int port = (int)(intptr_t)arg, one = 1;
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    if (ls < 0) { perror("[pc] socket"); return NULL; }
    fcntl(ls, F_SETFD, FD_CLOEXEC);                    // o SoftReset (exec) não pode herdar o socket
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons((uint16_t)port);
    const char *bindIp = getenv("PC_NET_BIND"); a.sin_addr.s_addr = bindIp ? inet_addr(bindIp) : htonl(INADDR_LOOPBACK);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0 || listen(ls, 1) < 0) { perror("[pc] bind/listen da ponte TCP"); return NULL; }
    fprintf(stderr, "[pc] aguardando o visualizador em %s:%d\n", bindIp ? bindIp : "127.0.0.1", port);
    static uint32_t frameBuf[240 * 160];
    static int16_t abuf[PC_AUDIO_RING_FRAMES * 2];
    for (;;) {
        int fd = accept(ls, NULL, NULL);
        if (fd < 0) continue;
        fcntl(fd, F_SETFD, FD_CLOEXEC);
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
        fprintf(stderr, "[pc] visualizador conectado\n");
        sSh->audioRead = sSh->audioWrite;              // descarta áudio acumulado enquanto ninguém ouvia
        uint32_t lastFrame = 0xFFFFFFFFu; uint8_t rbuf[64]; int rn = 0, ok = 1; uint8_t hdr[5];
        while (ok) {
            int did = 0;
            uint32_t fc = sSh->frameCounter;
            if (fc != lastFrame) {
                lastFrame = fc; memcpy(frameBuf, sSh->frame, sizeof frameBuf);
                uint32_t len = 4 + sizeof frameBuf; hdr[0] = 1; memcpy(hdr + 1, &len, 4);
                ok = SendAll(fd, hdr, 5) && SendAll(fd, &fc, 4) && SendAll(fd, frameBuf, sizeof frameBuf); did = 1;
            }
            uint32_t w = __atomic_load_n(&sSh->audioWrite, __ATOMIC_ACQUIRE), r = sSh->audioRead;
            if (ok && w != r) {
                uint32_t n = w - r; if (n > PC_AUDIO_RING_FRAMES) { r = w - PC_AUDIO_RING_FRAMES; n = PC_AUDIO_RING_FRAMES; }
                for (uint32_t i = 0; i < n; i++) { uint32_t pos = (r + i) % PC_AUDIO_RING_FRAMES; abuf[i * 2] = sSh->audio[pos * 2]; abuf[i * 2 + 1] = sSh->audio[pos * 2 + 1]; }
                uint32_t len = n * 4; hdr[0] = 2; memcpy(hdr + 1, &len, 4);
                ok = SendAll(fd, hdr, 5) && SendAll(fd, abuf, len);
                __atomic_store_n(&sSh->audioRead, w, __ATOMIC_RELEASE); did = 1;
            }
            ssize_t k = recv(fd, rbuf + rn, sizeof rbuf - (size_t)rn, MSG_DONTWAIT);
            if (k == 0) ok = 0;
            else if (k < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) ok = 0;
            else if (k > 0) rn += (int)k;
            while (rn >= 5) {
                uint32_t len; memcpy(&len, rbuf + 1, 4);
                if (len > sizeof rbuf - 5) { rn = 0; break; }                      // pacote inesperado: descarta o buffer
                if (rn < (int)(5 + len)) break;
                if (rbuf[0] == 3 && len == 4) { uint32_t keys; memcpy(&keys, rbuf + 5, 4); sSh->keyInput = keys & 0x3FF; }
                else if (rbuf[0] == 4) sSh->quit = 1;
                memmove(rbuf, rbuf + 5 + len, (size_t)(rn - 5 - (int)len)); rn -= 5 + (int)len;
            }
            if (!did) usleep(2000);
        }
        close(fd);
        sSh->keyInput = 0x3FF;
        fprintf(stderr, "[pc] visualizador desconectado\n");
    }
}

void PcNetStart(struct PcShared *sh) {
    const char *p = getenv("PC_NET_PORT");
    if (!p || !sh) return;
    sSh = sh;
    pthread_t th;
    if (pthread_create(&th, NULL, Bridge, (void *)(intptr_t)atoi(p)) == 0) pthread_detach(th);
}

#!/usr/bin/perl
# Expande recursivamente as linhas `.include "arquivo"` (caminhos relativos à raiz do repo),
# porque o assembler x86 não aceita algumas construções que o assembler ARM aceita nos .inc.
use strict;
sub expand { my ($fh,$depth)=@_; die "include profundo demais" if $depth>20;
  while(my $l=<$fh>){
    if($l=~/^\s*\.include\s+"([^"]+)"/){ my $p=$1; $p="sound/$p" unless -e $p; open(my $in,"<",$p) or die "nao achei $1"; expand($in,$depth+1); close $in; }
    else { print $l; } } }
expand(\*STDIN,0);
